# CryptoView - A simple crypto data app

Detail Screen
-> Name
-> Current Price (INR and USD)
-> Description
-> Symbol
-> Image (Logo)
-> Start Date (genesis date)
-> Market Capital
-> Last 2 weeks change



-> https://api.coingecko.com/api/v3/coins/bitcoin?localization=false&tickers=false&market_data=false&community_data=false&developer_data=false&sparkline=false
-> https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=inr%2Cusd
-> https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=inr&days=7

Chart Library -> https://www.chartjs.org/
Chart Library CDN -> https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js

Deployed At : https://my-crypto-currency-tracker.netlify.app/
